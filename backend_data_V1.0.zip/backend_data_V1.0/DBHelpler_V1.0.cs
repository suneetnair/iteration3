using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

/// <summary>
/// DBHelper explanation
/// </summary>
namespace ECOFriends.Controllers
{
    public class DBHelper
    {//server=.;Trusted_Connection=SSPI;database=easylife
        private String connectionString = "server=ecofriends.database.windows.net;database=ecofriends;uid=ecofriends;pwd=Tp9physis";

        public SqlDataReader ExecuteReader(String sql)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(sql,connection);

            SqlDataReader result = command.ExecuteReader();

            return result;
        }

        public bool ExecuteCommand(String sql)
        {
            bool result = false;

            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                SqlCommand command = new SqlCommand(sql,connection);
                //command.Connection = connection;
                //command.CommandText = sql;
                command.ExecuteNonQuery();


                connection.Close();

                result = true;
            }
            catch (Exception e)
            {
                throw e;
            }

            return result;
        }

    }
}
