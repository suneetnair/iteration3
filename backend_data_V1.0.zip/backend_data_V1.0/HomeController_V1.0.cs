using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ECOFriends.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Rules()
        {
            return View();
        }

        public ActionResult ChooseRooms()
        {
            return View();
        }

        public ActionResult Bedroom()
        {
            return View();
        }

        public ActionResult Bathroom()
        {
            return View();
        }

        public ActionResult Result()
        {
            return View();
        }

        public ActionResult Livingroom()
        {
            return View();
        }

        public ActionResult Study()
        {
            return View();
        }

        public ActionResult Story2()
        {
            return View();
        }
        
        public ActionResult Story3()
        {
            return View();
        }

        public ActionResult Character()
        {
            return View();
        }

        public ActionResult BedroomVisual()
        {
            return View();
        }

        public ActionResult BathroomVisual()
        {
            return View();
        }

        public ActionResult StudyVisual()
        {
            return View();
        }

        public ActionResult LivingroomVisual()
        {
            return View();
        }

        public ActionResult getData()
        {
          var data = new List<Object>();

          data.Add(new
          {
              count = 3,
              test = "hello world"
          });
          return Json(data, JsonRequestBehavior.AllowGet);
        }

    }
}