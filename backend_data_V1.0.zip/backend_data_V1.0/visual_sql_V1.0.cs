public ActionResult getData()
        {
          var data = new List<Object>();

          

          String sql = "";

            sql = "select appliance_type, annual_tree_number from ecofriends.appliance_electricity_tree";

            DBHelper helper = new DBHelper();
            SqlDataReader reader = helper.ExecuteReader(sql);
            if (reader.Read())
            {

              data.Add(new
              {
                  applianceType = reader.GetString(0);,
                  visualTreeNumber = reader.GetString(1);
              });
               
            }
            else 
            {
                return null;
            }
           
            return data;
          
          return Json(data, JsonRequestBehavior.AllowGet);
        }