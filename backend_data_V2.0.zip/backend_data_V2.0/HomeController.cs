﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ECOFriends.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Rules()
        {
            return View();
        }

        public ActionResult ChooseRooms()
        {
            return View();
        }

        public ActionResult Bedroom()
        {
            return View();
        }

        public ActionResult Bathroom()
        {
            return View();
        }

        public ActionResult Result()
        {
            return View();
        }

        public ActionResult Livingroom()
        {
            return View();
        }

        public ActionResult Study()
        {
            return View();
        }

        public ActionResult Story2()
        {
            return View();
        }
        
        public ActionResult Story3()
        {
            return View();
        }

        public ActionResult Character()
        {
            return View();
        }

        public ActionResult BedroomVisual()
        {
            return View();
        }

        public ActionResult BathroomVisual()
        {
            return View();
        }

        public ActionResult StudyVisual()
        {
            return View();
        }

        public ActionResult LivingroomVisual()
        {
            return View();
        }

        public ActionResult getData()
        {
            var data = new List<Object>();
            String sql = "";
            sql = "select appliance_type, annual_tree_number from appliance_electricity_tree";

            DBHelper helper = new DBHelper();
            SqlDataReader reader = helper.ExecuteReader(sql);
            while (reader.Read())
            {

                data.Add(new
                {
                    applianceType = reader.GetString(0),
                    visualTreeNumber = reader.GetDouble(1)
                });

            }
            

            return Json(data, JsonRequestBehavior.AllowGet);
        }

    }
}